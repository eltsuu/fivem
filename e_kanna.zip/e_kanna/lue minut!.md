# Kanna skripti tehnyt eltsunki
Kuinka käyttää:
Kirjoita consoleen tai chattiin /kanna ja pois ottaa samalla komennolla

Tää on vapaaseen käyttöön joten käytä jos siltä tuntuu omalla rp palvelimella!
